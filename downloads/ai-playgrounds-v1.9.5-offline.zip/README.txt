AI Playgrounds v1.9.5 - standalone offline classroom files

Extract this ZIP. Open any HTML in a modern desktop browser. Each HTML
works alone: copy or rename it and give it to students. No server, account,
installation, neighbouring files or internet connection is required.
Website links are optional online destinations. Do not use a ZIP viewer
or restricted LMS preview. Answers stay in the learner's browser, not
inside the HTML; copy/export/print them before clearing browser data.

Learner/educator usability studies and human screen-reader testing are
deferred. No WCAG conformance or validated learning gains are claimed.
